create definer = root@localhost view vue_densemble as
select `p_langue`.`demande`.`id`            AS `id`,
       `p_langue`.`demande`.`date`          AS `date`,
       `p_langue`.`participant`.`nom`       AS `nom`,
       `p_langue`.`participant`.`prenom`    AS `prenom`,
       `p_langue`.`participant`.`mail`      AS `mail`,
       `p_langue`.`participant`.`telephone` AS `telephone`,
       `p_langue`.`section`.`nom_section`   AS `nom_section`,
       `p_langue`.`section`.`nom_annee`     AS `nom_annee`,
       `p_langue`.`cours`.`nom_cours`       AS `nom_cours`,
       `p_langue`.`doc`.`nom_d1`            AS `nom_d1`,
       `p_langue`.`doc`.`nom_d2`            AS `nom_d2`,
       `p_langue`.`doc`.`nom_d3`            AS `nom_d3`,
       `p_langue`.`doc`.`nom_d4`            AS `nom_d4`,
       `p_langue`.`acquis`.`nom_acquis1`    AS `nom_acquis1`,
       `p_langue`.`acquis`.`nom_acquis2`    AS `nom_acquis2`,
       `p_langue`.`acquis`.`nom_acquis3`    AS `nom_acquis3`,
       `p_langue`.`acquis`.`nom_acquis4`    AS `nom_acquis4`,
       `p_langue`.`demande`.`deff`          AS `deff`
from (((((`p_langue`.`demande` join `p_langue`.`participant` on (`p_langue`.`demande`.`fk_participant` = `p_langue`.`participant`.`id`)) join `p_langue`.`section` on (`p_langue`.`participant`.`fk_section` = `p_langue`.`section`.`id`)) join `p_langue`.`cours` on (`p_langue`.`demande`.`fk_cours` = `p_langue`.`cours`.`id`)) join `p_langue`.`doc` on (`p_langue`.`demande`.`fk_doc` = `p_langue`.`doc`.`id`))
         join `p_langue`.`acquis` on (`p_langue`.`demande`.`fk_acquis` = `p_langue`.`acquis`.`id`));

