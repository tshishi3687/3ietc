create definer = root@localhost view vue_ensemble as
select `projet_x`.`article`.`enregistrement` AS `enregistrement`,
       `projet_x`.`article`.`photo`          AS `photo`,
       `projet_x`.`article`.`nom`            AS `nom`,
       `projet_x`.`marque`.`marque`          AS `marque`,
       `projet_x`.`genrre`.`genrre`          AS `genrre`,
       `projet_x`.`tyype`.`tyype`            AS `tyype`,
       `projet_x`.`quantite`.`quantite`      AS `quantite`,
       `projet_x`.`note`.`note`              AS `note`,
       `projet_x`.`prix`.`prix`              AS `prix`,
       `projet_x`.`enseigne`.`enseigne`      AS `enseigne`,
       `projet_x`.`commentaire`.`com`        AS `com`
from ((((((((`projet_x`.`article` join `projet_x`.`marque` on (`projet_x`.`article`.`marque` = `projet_x`.`marque`.`id_marque`)) join `projet_x`.`genrre` on (`projet_x`.`article`.`genre` = `projet_x`.`genrre`.`id_genrre`)) join `projet_x`.`tyype` on (`projet_x`.`article`.`type` = `projet_x`.`tyype`.`id_tyype`)) join `projet_x`.`prix` on (`projet_x`.`article`.`prix` = `projet_x`.`prix`.`id_Prix`)) join `projet_x`.`quantite` on (`projet_x`.`article`.`quentite` = `projet_x`.`quantite`.`id_quantite`)) join `projet_x`.`note` on (`projet_x`.`article`.`note` = `projet_x`.`note`.`id_note`)) join `projet_x`.`enseigne` on (`projet_x`.`prix`.`provence` = `projet_x`.`enseigne`.`id_ensei`))
         join `projet_x`.`commentaire` on (`projet_x`.`note`.`com` = `projet_x`.`commentaire`.`id_com`));

