create definer = root@localhost trigger Date_decision
    before update
    on demande
    for each row
    IF (NEW.ID_STA_DEMAND <>1) THEN
        SET NEW.DATE_DECISION = CURRENT_DATE();
    END IF;

