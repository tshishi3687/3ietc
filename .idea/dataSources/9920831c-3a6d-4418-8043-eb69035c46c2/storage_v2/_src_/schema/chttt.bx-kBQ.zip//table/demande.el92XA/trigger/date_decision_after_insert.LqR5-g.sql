create definer = root@localhost trigger date_decision_after_insert
    before insert
    on demande
    for each row
    IF (NEW.ID_STA_DEMAND <>1) THEN
        SET new.DATE_DECISION = CURRENT_DATE();
    END IF;

